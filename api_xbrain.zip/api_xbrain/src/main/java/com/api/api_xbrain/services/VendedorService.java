package com.api.api_xbrain.services;

import com.api.api_xbrain.models.Venda;
import com.api.api_xbrain.models.Vendedor;
import com.api.api_xbrain.repositories.VendedorRepositorie;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;

public class VendedorService {


    @Autowired
    private VendedorRepositorie vendedorRepositorie;

    public Venda Salvar(Venda venda){
        return vendedorRepositorie.save(venda);
    }

    public List<Vendedor> listarVenda(){
        return vendedorRepositorie.findAll();
    }

    public Optional<Vendedor> buscarporId(Long id){
        return vendedorRepositorie.findById(id);
    }

    public void removerporID (Long id){
        vendedorRepositorie.deleteById(id);
    }
}
