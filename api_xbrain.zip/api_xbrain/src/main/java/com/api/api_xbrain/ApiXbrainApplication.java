package com.api.api_xbrain;

import org.modelmapper.ModelMapper;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@SpringBootApplication
@RestController
public class ApiXbrainApplication {

	@Bean

	public ModelMapper modelMapper(){
	ModelMapper modelMaper = new ModelMapper();
	modelMaper.getConfiguration().setSkipNullEnabled(true);
	return modelMaper;
}



	public static void main(String[] args) {
		SpringApplication.run(ApiXbrainApplication.class, args);}

	@GetMapping("/")
	public String index(){
		return "ola mundo";

	}

}
