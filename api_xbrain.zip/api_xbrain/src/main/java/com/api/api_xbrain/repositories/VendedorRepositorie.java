package com.api.api_xbrain.repositories;

import com.api.api_xbrain.models.Vendedor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VendedorRepositorie extends JpaRepository<Vendedor, Long>

{
}
