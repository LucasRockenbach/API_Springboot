package com.api.api_xbrain.controllers;

import com.api.api_xbrain.models.Venda;
import com.api.api_xbrain.services.VendaService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/venda")
public class VendaController {

    @Autowired
    private VendaService vendaService;

    @Autowired
    private ModelMapper modelmapper;

    @PostMapping
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Venda salvar(@RequestBody Venda venda){

        return vendaService.Salvar(venda);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Venda> listaVenda(){
        return vendaService.listarVenda();
    }

    @GetMapping("/{id}")
    @ResponseStatus(HttpStatus.OK)

    public Venda buscarporId(@PathVariable("id") Long id){
        return vendaService.buscarporId(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "venda nao encontrado"));
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerVendedor(@PathVariable("id") Long id){
        vendaService.buscarporId(id)
                .map(vendedor -> {
                    vendaService.removerporID(id);
                    return Void.TYPE;
                }) .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Venda nao encontrado"));
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void atualizarCliente (@PathVariable("id") Long id, @RequestBody Venda vendedor){
        vendaService.buscarporId(id)
                .map(vendedorBase -> {
                    modelmapper.map(vendedor, vendedorBase);
                    vendaService.Salvar(vendedorBase);
                    return Void.TYPE;
                }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "venda nao encontrado"));
    }
}
