package com.api.api_xbrain.repositories;

import com.api.api_xbrain.models.Venda;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VendaRepositorie extends JpaRepository <Venda, Long> {
}
