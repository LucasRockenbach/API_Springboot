package com.api.api_xbrain.controllers;

import com.api.api_xbrain.models.Venda;
import com.api.api_xbrain.models.Vendedor;
import com.api.api_xbrain.services.VendedorService;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

@RestController
@RequestMapping("/vendedor")
public class VendedorController {

    @Autowired
    private VendedorService vendedorService;

    @Autowired
    private ModelMapper modelmapper;

    @PostMapping
    @ResponseStatus(HttpStatus.ACCEPTED)
    public Vendedor salvar(@RequestBody Vendedor vendedor){

        return vendedorService.Salvar((Venda) vendedor);
    }

    @GetMapping
    @ResponseStatus(HttpStatus.OK)
    public List<Vendedor> listaVendedor(){
        return vendedorService.listarVenda();
    }

    @GetMapping("/{idVendedor}")
    @ResponseStatus(HttpStatus.OK)

    public Vendedor buscarporId(@PathVariable("id") Long id){
        return vendedorService.buscarporId(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "vendedor nao encontrado"));
    }

    @DeleteMapping("/{idVendedor}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void removerVendedor(@PathVariable("id") Long id){
        vendedorService.buscarporId(id)
                .map(vendedor -> {
                    vendedorService.removerporID(id);
                    return Void.TYPE;
                }) .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Vendedor nao encontrado"));
    }

    @PutMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void atualizarCliente (@PathVariable("id") Long id, @RequestBody Vendedor vendedor){
        vendedorService.buscarporId(id)
                .map(vendedorBase -> {
                    modelmapper.map(vendedor, vendedorBase);
                    vendedorService.Salvar((Venda) vendedorBase);
                    return Void.TYPE;
                }).orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "vendedor nao encontrado"));
    }
}

