package com.api.api_xbrain.services;

import com.api.api_xbrain.models.Venda;
import com.api.api_xbrain.repositories.VendaRepositorie;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;
import java.util.Optional;


public class VendaService {

    @Autowired
    private VendaRepositorie vendaRepositorie;

    public Venda Salvar(Venda venda){
        return vendaRepositorie.save(venda);
    }

    public List<Venda> listarVenda(){
        return vendaRepositorie.findAll();
    }

    public Optional<Venda> buscarporId(Long id){
        return vendaRepositorie.findById(id);
    }

    public void removerporID (Long id){
        vendaRepositorie.deleteById(id);
    }

}
