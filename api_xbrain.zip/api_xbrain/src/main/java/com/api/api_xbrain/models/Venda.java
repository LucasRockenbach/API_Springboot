package com.api.api_xbrain.models;


import jakarta.persistence.*;
import lombok.*;

import java.io.Serializable;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor

@Entity
public class Venda extends Vendedor implements Serializable {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)


    private Long id;

    @Column(name = "data", nullable = false )
    private Date data;

    @Column(name = "valor")
    private double valor;


}
