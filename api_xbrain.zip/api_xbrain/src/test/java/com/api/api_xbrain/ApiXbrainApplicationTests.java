package com.api.api_xbrain;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApiXbrainApplicationTests {

	@Test
	void contextLoads() {
	}

}
